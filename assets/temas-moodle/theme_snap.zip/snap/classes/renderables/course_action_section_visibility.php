<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Course action for affecting section visibility.
 * @author    gthomas2
 * @copyright Copyright (c) 2016 Open LMS (https://www.openlms.net)
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace theme_snap\renderables;
use context_course;
use moodle_url;
use section_info;

class course_action_section_visibility extends course_action_section_base {

    /**
     * @var string
     */
    public $class = 'snap-visibility';

    public function __construct($course, section_info $section, $onsectionpage = false) {

        $baseurl = new moodle_url('/course/format/update.php', [
            'sesskey' => sesskey(),
            'id' => $section->id,
            'courseid' => $course->id,
        ]);

        $coursecontext = context_course::instance($course->id);

        $url = clone($baseurl);
        if (has_capability('moodle/course:sectionvisibility', $coursecontext)) {
            // If we are in a Delegated Section, validate Parent Visibility.
            if ($section->is_delegated()) {
                // Get parent section information.
                $cm = $section->delegateinstance->get_cm();
                $parentsection = $cm->get_section_info();
                if (!$parentsection->visible) {
                    $this->class .= ' d-none';
                }
            }

            $this->title = get_string('hidefromothers', 'format_'.$course->format) . '/' . get_string('showfromothers', 'format_'.$course->format);

            if ($section->visible) { // Show the hide/show eye.
                $url->param('action', 'section_hide');
                $this->url = $url;
                $this->class .= ' snap-hide dropdown-item editing_showhide menu-action';
                $this->arialabel = "aria-label='".get_string('hidefromothers', 'format_'.$course->format)."'";
                $this->dataaction = 'sectionHide';
                $this->dataid = $section->id;
            } else {
                $url->param('action',  'section_show');
                $this->url = $url;
                $this->class .= ' snap-show dropdown-item editing_showhide menu-action';
                $this->arialabel = "aria-label='".get_string('showfromothers', 'format_'.$course->format)."'";
                $this->dataaction = 'sectionShow';
                $this->dataid = $section->id;
            }
        }
    }
}
