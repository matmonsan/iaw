# This file is part of Moodle - http://moodle.org/
#
# Moodle is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# Moodle is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
#
# Tests for toggle course section visibility in non edit mode in snap.
#
# @package    theme_snap
# @copyright  2015 Guy Thomas
# @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later

@theme @theme_snap @theme_snap_course
Feature: When the moodle theme is set to Snap, teachers can toggle the visibility of course sections in read mode and
  edit mode.

  Background:
    Given the following "courses" exist:
      | fullname | shortname | category | format | initsections |
      | Course 1 | C1        | 0        | topics |      1       |
    And the following "users" exist:
      | username | firstname | lastname | email |
      | teacher1 | Teacher | 1 | teacher1@example.com |
      | student1 | Student | 1 | student1@example.com |
    And the following "course enrolments" exist:
      | user | course | role |
      | admin | C1 | editingteacher |
      | teacher1 | C1 | editingteacher |
      | student1 | C1 | student |
    And the following "activities" exist:
      | activity   | name               | course | section |
      | subsection | SubsectionExample  | C1     | 1      |
    And I enable "subsection" "mod" plugin

  @javascript
  Scenario: In read mode, teacher hides section and show an activity.
    Given I log in as "admin"
    And I am on the course main page for "C1"
    And I follow "Section 1"
    And I wait until the page is ready
    And I click on "#section-1 .snap-visibility[data-action='sectionHide']" "css_element"
    And I follow "Section 1"
    And I wait until the page is ready
    And I wait until "#section-1 .snap-visibility[data-action='sectionShow']" "css_element" exists
    And I reload the page
    And I add a assign activity to course "C1" section "1" and I fill the form with:
      | Assignment name | Assignment One          |
      | Description     | Submit your online text |
      | visible         | 1                       |
    And I am on the course main page for "C1"
    And I follow "Section 1"
    And I wait until the page is ready
    And "Available but not shown on course page" "text" should exist in the "Assignment One" "activity"
    And I click on "#section-1 .snap-visibility[data-action='sectionShow']" "css_element"
    And I follow "Section 1"
    And I wait until the page is ready
    And I wait until "#section-1 .snap-visibility[data-action='sectionHide']" "css_element" exists
    Then "Available but not shown on course page" "text" should not exist in the "Assignment One" "activity"

  @javascript
  Scenario: In read mode, teacher hides section and hide an activity.
    Given I log in as "admin"
    And I am on the course main page for "C1"
    And I add a assign activity to course "C1" section "1" and I fill the form with:
      | Assignment name | Assignment One          |
      | Description     | Submit your online text |
      | visible         | 0                       |
    And I am on the course main page for "C1"
    And I follow "Section 1"
    And I wait until the page is ready
    Then I should see "Hidden from students"
    And I click on "#section-1 .snap-visibility[data-action='sectionHide']" "css_element"
    And I follow "Section 1"
    And I wait until the page is ready
    And I wait until "#section-1 .snap-visibility[data-action='sectionShow']" "css_element" exists
    Then ".snap-asset.draft .snap-draft-tag" "css_element" should not be visible
    And I click on "#section-1 .snap-visibility[data-action='sectionShow']" "css_element"
    And I follow "Section 1"
    And I wait until the page is ready
    And I wait until "#section-1 .snap-visibility[data-action='sectionHide']" "css_element" exists
    Then I should see "Hidden from students"

  @javascript
  Scenario: Teacher loses teacher capability whilst course open and receives the correct error message when trying to
  hide section.
    Given I log in as "teacher1"
    And I am on the course main page for "C1"
    And the editing teacher role is removed from course "C1" for "teacher1"
    And I follow "Section 1"
    And I wait until the page is ready
    Then "#section-1" "css_element" should exist
    And "#section-1 .snap-visibility[data-action='sectionHide']" "css_element" should not exist

  @javascript
  Scenario: Teacher loses teacher capability whilst course open and when rendering using the fragment api the edition
  button should not appear.
    Given I log in as "admin"
    And I log out
    Then I log in as "teacher1"
    And I am on the course main page for "C1"
    And the editing teacher role is removed from course "C1" for "teacher1"
    And I follow "Section 1"
    And I wait until the page is ready
    Then "#section-1" "css_element" should exist
    And "#section-1 .snap-visibility[data-action='sectionHide']" "css_element" should not exist

  @javascript
  Scenario: In read mode, student cannot hide section.
    Given I log in as "admin"
    And I log out
    Then I log in as "student1"
    And I am on the course main page for "C1"
    And I follow "Section 2"
    And I wait until the page is ready
    Then "#section-2 .snap-visibility" "css_element" should not exist

  @javascript @test3
  Scenario: Section footer buttons follow edit mode state when toggling section visibility without page reload.
    Given I log in as "admin"
    And I am on the course main page for "C1"
    And I follow "Section 1"
    And I wait until the page is ready
    And "#section-1 .btn-add-activity" "css_element" should be visible
    And "#snap-drop-file-1" "css_element" should exist
    When I click on "#section-1 .snap-visibility[data-action='sectionHide']" "css_element"
    And I wait until "#section-1 .snap-visibility[data-action='sectionShow']" "css_element" exists
    Then "#section-1 .btn-add-activity" "css_element" should be visible
    And "#snap-drop-file-1" "css_element" should exist
    When I click on "#section-1 .snap-visibility[data-action='sectionShow']" "css_element"
    And I wait until "#section-1 .snap-visibility[data-action='sectionHide']" "css_element" exists
    Then "#section-1 .btn-add-activity" "css_element" should be visible
    And "#snap-drop-file-1" "css_element" should exist
    And I turn editing mode on
    And "#section-1 .btn-add-activity" "css_element" should not exist
    And "#snap-drop-file-1" "css_element" should not exist
    When I click on "#section-1 .snap-visibility[data-action='sectionHide']" "css_element"
    And I wait until "#section-1 .snap-visibility[data-action='sectionShow']" "css_element" exists
    Then "#section-1 .btn-add-activity" "css_element" should not exist
    And "#snap-drop-file-1" "css_element" should not exist
    When I click on "#section-1 .snap-visibility[data-action='sectionShow']" "css_element"
    And I wait until "#section-1 .snap-visibility[data-action='sectionHide']" "css_element" exists
    Then "#section-1 .btn-add-activity" "css_element" should not exist
    And "#snap-drop-file-1" "css_element" should not exist

  @javascript
  Scenario: When parent Section is Hidden, Subsections can not modify visibility.
    Given I log in as "teacher1"
    And I am on the course main page for "C1"
    And I follow "Section 1"
    And I wait until the page is ready
    Then "#section-1" "css_element" should exist
    And I click on "#section-1 .snap-visibility[data-action='sectionHide']" "css_element"
    Then I should see "Hidden from students"
    And "#section-1 .snap-visibility" "css_element" should be visible
    And I open "SubsectionExample" actions menu
    And I click on "View" "link" in the "SubsectionExample" activity
    And I wait until the page is ready
    And ".section.main.state-visible .snap-visibility" "css_element" should not be visible
    # Showing the parent again should restore the subsection's own visibility toggle.
    And I am on the course main page for "C1"
    And I follow "Section 1"
    And I wait until the page is ready
    And I click on "#section-1 .snap-visibility[data-action='sectionShow']" "css_element"
    And I wait until "#section-1 .snap-visibility[data-action='sectionHide']" "css_element" exists
    And I open "SubsectionExample" actions menu
    And I click on "View" "link" in the "SubsectionExample" activity
    And I wait until the page is ready
    Then ".section.main.state-visible .snap-visibility" "css_element" should be visible

  @javascript
  Scenario: A subsection repeatedly visited via the course index without a page reload always
  reflects its parent section's current visibility.
    Given I log in as "teacher1"
    And I am on the course main page for "C1"
    And I follow "Section 1"
    And I wait until the page is ready
    # Visit the subsection once via the course index (no page reload), so a copy gets cached.
    And I click on "SubsectionExample" "link" in the "nav#courseindex" "css_element"
    And I wait until the page is ready
    And ".section.main.state-visible .snap-visibility" "css_element" should be visible
    # Go back to Section 1 (still without a page reload) and hide it.
    And I click on "Section 1" "link" in the "nav#courseindex" "css_element"
    And I wait until the page is ready
    And I click on "#section-1 .snap-visibility[data-action='sectionHide']" "css_element"
    Then I should see "Hidden from students"
    # Visit the subsection again via the course index: it must reflect the parent now being
    # hidden, not the copy cached from the first visit.
    And I click on "SubsectionExample" "link" in the "nav#courseindex" "css_element"
    And I wait until the page is ready
    And ".section.main.state-visible .snap-visibility" "css_element" should not be visible
    # Show the parent again and re-visit: the subsection's toggle should be visible once more.
    And I click on "Section 1" "link" in the "nav#courseindex" "css_element"
    And I wait until the page is ready
    And I click on "#section-1 .snap-visibility[data-action='sectionShow']" "css_element"
    And I wait until "#section-1 .snap-visibility[data-action='sectionHide']" "css_element" exists
    And I click on "SubsectionExample" "link" in the "nav#courseindex" "css_element"
    And I wait until the page is ready
    Then ".section.main.state-visible .snap-visibility" "css_element" should be visible