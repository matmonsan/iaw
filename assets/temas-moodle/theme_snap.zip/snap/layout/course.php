<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Layout - course.
 *
 * @package   theme_snap
 * @copyright Copyright (c) 2015 Open LMS (https://www.openlms.net)
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

use theme_snap\local;

defined('MOODLE_INTERNAL') || die();

require(__DIR__.'/header.php');

$coursemainpage = strpos($PAGE->pagetype, 'course-view-') === 0;

$mastimage = ($COURSE->id != SITEID && local::has_cover_image()) ? 'mast-image' : '';
// Check if in current path we must to hide TOC.
$pathurl = local::current_url_path();
$pathurl = $OUTPUT->get_path_hiddentoc($pathurl);
?>
<!-- Moodle js hooks -->
<div id="page">
<div id="page-content">

<!--
////////////////////////// MAIN  ///////////////////////////////
-->
<div id="moodle-page" class="clearfix">
<?php
echo $OUTPUT->custom_menu_spacer();
?>
<div id="page-header" class="clearfix <?php echo $mastimage; ?>">
    <nav class="breadcrumb-nav" aria-label="breadcrumbs"><?php echo $OUTPUT->navbar(); ?></nav>

    <?php
    if ($coursemainpage) {
        $output = $PAGE->get_renderer('core', 'course');
    }
    // Allow individual course formats to set their preferred values.
    switch ($COURSE->format) {
        case 'weeks':
            $PAGE->set_heading($COURSE->fullname);
            break;
        default:
            break;
    }
    echo $OUTPUT->snap_page_header();
    ?>
</div>
<?php
echo '<div id="snap-course-wrapper">';
require __DIR__ . '/course_index_drawer.php';
echo '<div class="row">';
echo '<div class="col-lg-12">';
?>
<section id="region-main">

<?php
echo $OUTPUT->course_content_header();
$output = $PAGE->get_renderer('core', 'course');
echo $output->snap_footer_alert();
echo $OUTPUT->course_modchooser();
echo $OUTPUT->main_content();
echo \theme_snap\output\shared::course_tools(true);
echo $OUTPUT->course_content_footer();
?>
</section>
<?php
require __DIR__.'/blocks_drawer.php';
echo $OUTPUT->snap_feeds_side_menu();

// Call listeners for Section actions from Core.
if (!$this->page->user_is_editing()) {
    $PAGE->requires->js_call_amd('core_course/actions', 'initCoursePage', array($COURSE->format));
}
echo '</div> <!-- close section -->';
echo '</div> <!-- close row -->';
echo '</div> <!-- close course wrapper -->';

if ($coursemainpage) {
    $coursefooter = $output->course_footer();
    if (!empty($coursefooter)) { ?>
        <div id="snap-course-footer"><?php echo $coursefooter ?></div>
        <?php
    }
} ?>
</div>

</div>
</div>
<?php echo $OUTPUT->standard_after_main_region_html() ?>
<!-- close moodle js hooks -->

<?php require(__DIR__.'/footer.php');
